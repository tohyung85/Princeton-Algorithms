import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.In;
import java.util.*;


public class FastCollinearPoints {
    private int numSegments;
    private LineSegment[] lineSegments;
    
    public FastCollinearPoints(Point[] points) {    // finds all line segments containing 4 or more points
        numSegments = 0;
        lineSegments = new LineSegment[points.length];
        Merge msort = new Merge();
        for(int i=0; i<points.length; i++) {
            msort.sortBySlope(points, points[i]);
            int numberCollinear = 1;
            Point op = points[0];
            Comparator<Point> pc = op.slopeOrder();
            Point minPoint = points[1];
            
            for(int j=1; j<points.length; j++) {
                if(!(pc.compare(points[j-1], points[j]) < 0)) {
                    numberCollinear++;
                } else {
                    if(numberCollinear > 2) {
                        if(op.compareTo(minPoint) < 0) {
                            LineSegment line = new LineSegment(op, points[j-1]);
                            lineSegments[numSegments++] = line;
                        }
                    }
                    numberCollinear = 1;                    
                    minPoint = points[j];
                }
            }
            
            Arrays.sort(points); // reset to sort by position to maintain stability
        }
    }
    
    public int numberOfSegments() {        // the number of line segments
        return numSegments;
    }
    
    public LineSegment[] segments() {               // the line segments
        int num = numberOfSegments();
        LineSegment[] ls = new LineSegment[num];
        for(int i = 0; i< num; i++) {
            ls[i] = lineSegments[i];
        }
        return ls;
    }
    
    private void throwException(int i) { 
        switch (i) { 
            case 0: 
                throw new NullPointerException("null array or null points not allowed");
            case 1: 
                throw new IllegalArgumentException("No repeat points allowed!");
            default: 
                throw new UnsupportedOperationException("Oops something went wrong"); 
        }
    }
    
    private class Merge {        
        private void merge(Point[] points, Point[] aux, Comparator<Point> pc, int lo, int hi, int mid) {
            for(int i=lo; i<=hi; i++) {
                aux[i] = points[i];
            }
           
            int k = lo;
            int j = mid + 1;
            for(int i=lo; i<=hi; i++) {
                if(k > mid) { 
                    points[i] = aux[j++];
                } else if(j > hi) {
                    points[i] = aux[k++];
                } else if(pc.compare(aux[j], aux[k]) < 0) {
                    points[i] = aux[j++];
                } else {
                    points[i] = aux[k++];
                }
            }
        }

        private void sortBySlope(Point[] points, Point[] aux, Comparator<Point> pc, int lo, int hi) {
            if(hi <= lo) {
                return;
            }
            
            int mid = lo + (hi-lo)/2;
            
            sortBySlope(points, aux, pc, lo, mid);
            sortBySlope(points, aux, pc, mid+1, hi);
            merge(points, aux, pc, lo, hi, mid);
        }
        
        public void sortBySlope(Point[] points, Point p) {
            Point[] aux = new Point[points.length];
            Comparator<Point> pc = p.slopeOrder();
            sortBySlope(points, aux, pc, 0, points.length-1);
        }
    }
    
    public static void main(String[] args) {
        
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }
        
        Arrays.sort(points);

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();
        
        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
        
        /*
        Point p1 = new Point(0,1);
        Point p2 = new Point(2,5);
        Point op = new Point(1,1);
        Point p3 = new Point(5,2);
        Point p4 = new Point(2,7);
        Point[] points = new Point[5];
        points[0] = p1;
        points[1] = p2;
        points[2] = op;   
        points[3] = p3; 
        points[4] = p4; 
        
        for(int i=0; i<5; i++) {
            StdOut.println(points[i].toString());
        }
        
        Arrays.sort(points);
        StdOut.println("---Sorted---");
        for(int i=0; i<5; i++) {
            StdOut.println(points[i].toString());
        }
        
        FastCollinearPoints fcp = new FastCollinearPoints(points);
        StdOut.println("---Sorted By Order---");
        for(int i=0; i<5; i++) {
            StdOut.println(points[i].toString());
        }
        */
    }
}